<?php
/**
 * Zira project.
 * category.php
 * (c)2016 https://github.com/ziracms/zira
 */

namespace Dash\Windows;

use Zira;
use Zira\Permission;

class Category extends Window {
    protected static $_icon_class = 'glyphicon glyphicon-book';
    protected static $_title = 'Category';

    public $item;

    public function init() {
        $this->setIconClass(self::$_icon_class);
        $this->setTitle(Zira\Locale::t(self::$_title));
        $this->setSidebarEnabled(false);

        $this->setSaveActionEnabled(true);
    }

    public function create() {
        $this->setOnLoadJSCallback(
            $this->createJSCallback(
                'desk_call(dash_category_load, this);'
            )
        );
        
        $this->includeJS('dash/category');
    }

    public function load() {
        if (!empty($this->item)) $this->item=intval($this->item);
        if ((!Permission::check(Permission::TO_CREATE_RECORDS) && !Permission::check(Permission::TO_EDIT_RECORDS)) ||
            (empty($this->item) && !Permission::check(Permission::TO_CREATE_RECORDS)) ||
            (!empty($this->item) && !Permission::check(Permission::TO_EDIT_RECORDS))
        ) {
            return array('error'=>Zira\Locale::t('Permission denied'));
        }

        $root = (string)Zira\Request::post('root');

        $this->setData(array(
            'root'=>$root,
            'items'=>$this->item ? array($this->item) : null
        ));

        $form = new \Dash\Forms\Category();

        if (!empty($this->item)) {
            $category = new Zira\Models\Category($this->item);
            if (!$category->loaded()) {
                return array('error'=>Zira\Locale::t('An error occurred'));
            }
            $this->setTitle(Zira\Locale::t('Category: %s', $category->name));
            $categoryArray = $category->toArray();
            if (!empty($root)) {
                $categoryArray['name'] = substr($categoryArray['name'], strrpos($categoryArray['name'], '/') + 1);
            }
            if ($categoryArray['comments_enabled']===null) $categoryArray['comments_enabled'] = Zira\Config::get('comments_enabled', 1);

            $form->setValues($categoryArray);
        } else {
            $this->setTitle(Zira\Locale::t('New category'));
            $form->setValues(array(
                'comments_enabled' => Zira\Config::get('comments_enabled', 1)
            ));
        }

        $form->setValue('root', $root);

        $this->setBodyContent($form);
    }
}