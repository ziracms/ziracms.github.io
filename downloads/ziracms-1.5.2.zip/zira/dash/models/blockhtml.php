<?php
/**
 * Zira project.
 * blockhtml.php
 * (c)2016 https://github.com/ziracms/zira
 */

namespace Dash\Models;

use Zira;

class Blockhtml extends Blocktext {

}