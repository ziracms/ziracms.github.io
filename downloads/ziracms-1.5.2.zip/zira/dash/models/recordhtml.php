<?php
/**
 * Zira project.
 * recordhtml.php
 * (c)2016 https://github.com/ziracms/zira
 */

namespace Dash\Models;

use Zira;
class Recordhtml extends Recordtext {

}