<?php

return array(
    'Edit message' => 'Редактировать сообщение',
    'Reply' => 'Ответить',
    'Quote' => 'Цитата',
    'Copy' => 'Копировать'
);