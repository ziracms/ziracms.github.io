<?php

return array(
    'Vote' => 'Голосование',
    'Votes' => 'Голосование',
    'Let your website visitors to vote' => 'Дайте вашим пользователям возможность голосовать',
    'Vote subject' => 'Тема голосования',
    'New vote subject' => 'Новая тема для голосования',
    'Subject' => 'Тема',
    'Multiple selection' => 'Множественный выбор',
    'Widget placeholder' => 'Расположение виджета',
    'Vote options' => 'Опции для выбора',
    'Add vote option' => 'Добавить опцию выбора',
    'Enter text' => 'Введите текст',
    'Votes: %s' => 'Голосов: %s',
    'Vote!' => 'Голосовать!',
    'Vote results' => 'Результаты голосования',
    'Results' => 'Результаты'
);