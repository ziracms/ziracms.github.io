<?php

return array(
    'Emoji' => 'Смайлики',
    'Add emoji to your website' => 'Добавь смайлики на свой сайт',
    'Select emoji' => 'Выберите смайлик',
    'Image' => 'Изображение',
    'Quote' => 'Цитата',
    'Code' => 'Код',
    'Bold' => 'Жирный',
    'Enter image URL address' => 'Введите URL адрес изображения'
);