<?php

return array(
    'Themes designer' => 'Дизайнер тем',
    'Create your own theme' => 'Создайте свою собственную тему',
    'Style' => 'Стиль',
    'New style' => 'Новый стиль',
    'Style editor' => 'Редактор стиля',
    'Enter title' => 'Введите заголовок',
    'Code' => 'Код',
    'CSS code' => 'CSS код',
    'Syntax error' => 'Синтаксическая ошибка',
    'main style' => 'основной стиль',
    'Color' => 'Цвет',
    'Theme font' => 'Шрифт темы',
    'Style has no changes' => 'Нет изменений в стиле'
);