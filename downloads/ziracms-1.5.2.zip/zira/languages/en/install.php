<?php

return array(
    'min. %s char' => array('min. %s char', 'min. %s chars'),
);