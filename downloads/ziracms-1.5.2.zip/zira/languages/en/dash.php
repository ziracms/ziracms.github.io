<?php

return array(
    'Deactivated %s users' => array('Deactivated %s user', 'Deactivated %s users'),
    'Activated %s users' => array('Activated %s user', 'Activated %s users'),
    'Deactivated %s groups' => array('Deactivated %s group', 'Deactivated %s groups'),
    'Activated %s groups' => array('Activated %s group', 'Activated %s groups'),
    'Deleted %s groups' => array('Deleted %s group', 'Deleted %s groups'),
    'Deactivated %s widgets' => array('Deactivated %s widget', 'Deactivated %s widgets'),
    'Activated %s widgets' => array('Activated %s widget', 'Activated %s widgets'),
    'Activated %s comments' => array('Activated %s comment', 'Activated %s comments'),
    '%s comments was posted' => array('%s comment was posted', '%s comments was posted'),
    'max. length: %s chars' => array('max. length: %s char', 'max. length: %s chars'),
    'Updated %s thumbs' => array('Updated %s thumb', 'Updated %s thumbs'),
    '%s downloads' => array('%s download', '%s downloads'),
    'Display records list in %s columns' => array('Display records list in %s column', 'Display records list in %s columns')
);