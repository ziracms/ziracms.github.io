<?php

return array(
    'At least %s characters required' => array('At least %s character required','At least %s characters required'),
);