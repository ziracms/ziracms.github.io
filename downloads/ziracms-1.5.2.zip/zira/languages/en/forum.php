<?php

return array(
    '%s forum messages was posted' => array('%s forum message was posted', '%s forum messages was posted'),
    'Published %s messages' => array('Published %s message', 'Published %s messages')
);