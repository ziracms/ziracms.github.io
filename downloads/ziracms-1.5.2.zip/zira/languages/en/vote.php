<?php

return array(
    'Activated %s widgets' => array('Activated %s widget', 'Activated %s widgets')
);