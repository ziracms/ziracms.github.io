<?php
echo !empty($_GET['q']) ? 1 : 0;