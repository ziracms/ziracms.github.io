<?php
/**
 * Zira project
 * zira.php
 * (c)2015 https://github.com/ziracms/zira
 */

class Zira extends \Zira\Zira {

}