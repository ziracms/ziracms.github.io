<?php
/**
 * Zira project.
 * field.php
 * (c)2015 https://github.com/ziracms/zira
 */

namespace Zira\Db;

class Field extends Mysql\Field implements Implement\Field {

}