<?php
/**
 * Zira project.
 * alter.php
 * (c)2017 https://github.com/ziracms/zira
 */

namespace Zira\Db;

class Alter extends Mysql\Alter implements Implement\Alter {

}