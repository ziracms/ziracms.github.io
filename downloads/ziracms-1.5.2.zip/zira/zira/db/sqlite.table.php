<?php
/**
 * Zira project.
 * sqlite.table.php
 * (c)2016 https://github.com/ziracms/zira
 */

namespace Zira\Db;

abstract class Table extends Sqlite\Table implements Implement\Table {

}