<?php
/**
 * Zira project.
 * db.php
 * (c)2015 https://github.com/ziracms/zira
 */

namespace Zira\Db;

class Db extends Mysql\Db implements Implement\Db {

}