<?php
/**
 * Zira project.
 * sqlite.orm.php
 * (c)2016 https://github.com/ziracms/zira
 */

namespace Zira\Db;

abstract class Orm extends Sqlite\Orm implements Implement\Orm {

}