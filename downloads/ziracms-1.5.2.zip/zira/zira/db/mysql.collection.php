<?php
/**
 * Zira project.
 * collection.php
 * (c)2015 https://github.com/ziracms/zira
 */

namespace Zira\Db;

class Collection extends Mysql\Collection implements Implement\Collection {

}