<?php
/**
 * Zira project
 * collection.php
 * (c)2015 https://github.com/ziracms/zira
 */

namespace Zira;

class Collection extends Db\Collection {

}