<?php
/**
 * Zira project.
 * cron.php
 * (c)2016 https://github.com/ziracms/zira
 */

namespace Zira;

interface Cron {
    public function run();
}