<?php
/**
 * Zira project
 * collection.php
 * (c)2015 http://dro1d.ru
 */

namespace Zira;

class Collection extends Db\Collection {

}