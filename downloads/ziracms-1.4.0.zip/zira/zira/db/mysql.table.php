<?php
/**
 * Zira project.
 * table.php
 * (c)2015 http://dro1d.ru
 */

namespace Zira\Db;

abstract class Table extends Mysql\Table implements Implement\Table {

}