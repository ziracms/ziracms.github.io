<?php
/**
 * Zira project.
 * field.php
 * (c)2015 http://dro1d.ru
 */

namespace Zira\Db;

class Field extends Mysql\Field implements Implement\Field {

}