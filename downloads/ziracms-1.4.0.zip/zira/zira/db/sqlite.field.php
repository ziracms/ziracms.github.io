<?php
/**
 * Zira project.
 * sqlite.field.php
 * (c)2016 http://dro1d.ru
 */

namespace Zira\Db;

class Field extends Sqlite\Field implements Implement\Field {

}