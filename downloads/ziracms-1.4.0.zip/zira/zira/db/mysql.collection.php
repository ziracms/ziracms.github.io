<?php
/**
 * Zira project.
 * collection.php
 * (c)2015 http://dro1d.ru
 */

namespace Zira\Db;

class Collection extends Mysql\Collection implements Implement\Collection {

}