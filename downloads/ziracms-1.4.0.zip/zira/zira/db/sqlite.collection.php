<?php
/**
 * Zira project.
 * sqlite.collection.php
 * (c)2016 http://dro1d.ru
 */

namespace Zira\Db;

class Collection extends Sqlite\Collection implements Implement\Collection {

}