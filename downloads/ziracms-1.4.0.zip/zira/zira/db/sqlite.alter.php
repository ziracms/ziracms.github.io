<?php
/**
 * Zira project.
 * alter.php
 * (c)2017 http://dro1d.ru
 */

namespace Zira\Db;

class Alter extends Sqlite\Alter implements Implement\Alter {

}