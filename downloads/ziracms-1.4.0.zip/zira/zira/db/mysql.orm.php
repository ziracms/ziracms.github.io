<?php
/**
 * Zira project.
 * orm.php
 * (c)2015 http://dro1d.ru
 */

namespace Zira\Db;

abstract class Orm extends Mysql\Orm implements Implement\Orm {

}