<?php
/**
 * Zira project.
 * sqlite.table.php
 * (c)2016 http://dro1d.ru
 */

namespace Zira\Db;

abstract class Table extends Sqlite\Table implements Implement\Table {

}