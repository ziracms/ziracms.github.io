<?php
/**
 * Zira project.
 * sqlite.orm.php
 * (c)2016 http://dro1d.ru
 */

namespace Zira\Db;

abstract class Orm extends Sqlite\Orm implements Implement\Orm {

}