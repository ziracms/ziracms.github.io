<?php
/**
 * Zira project.
 * sqlite.db.php
 * (c)2016 http://dro1d.ru
 */

namespace Zira\Db;

class Db extends Sqlite\Db implements Implement\Db {

}