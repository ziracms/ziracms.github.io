<?php
/**
 * Zira project.
 * db.php
 * (c)2015 http://dro1d.ru
 */

namespace Zira\Db;

class Db extends Mysql\Db implements Implement\Db {

}