<?php
/**
 * Zira project
 * orm.php
 * (c)2015 http://dro1d.ru
 */

namespace Zira;

abstract class Orm extends Db\Orm{

}