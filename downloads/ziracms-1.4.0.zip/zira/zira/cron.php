<?php
/**
 * Zira project.
 * cron.php
 * (c)2016 http://dro1d.ru
 */

namespace Zira;

interface Cron {
    public function run();
}