<?php

return array(
    'en' => 'English',
    'Added %s files' => array('Added %s file', 'Added %s files'),
    'Message should contain at least %s characters' => array('Message should contain at least %s character', 'Message should contain at least %s characters')
);