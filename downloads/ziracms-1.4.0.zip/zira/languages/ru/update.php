<?php

return array(
    'Update' => 'Обновить',
    'Zira CMS update wizzard' => 'Мастер обновления Zira CMS',
    'Zira CMS is ready to update.' => 'Zira CMS готова к обновлению.',
    'Database version: %s' => 'Версия базы данных: %s',
    'Database needs to be updated to version: %s' => 'База данных должна быть обновлена до версии: %s',
    'Error' => 'Ошибка',
    'Message' => 'Сообщение',
    'Close' => 'Закрыть',
    'An error occurred' => 'Возникла ошибка',
    'Please wait...' => 'Пожалуйста, подождите...',
    'Please wait' => 'Пожалуйста, подождите',
    'Update in progress' => 'Идёт обновление',
    'Updated successfully!' => 'Успешно обновлено!',
    'An error occurred.' => 'Возникла ошибка.',
    'Database is up to date.' => 'База данных обновлена.'
);