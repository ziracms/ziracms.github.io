<?php
/**
 * Zira project.
 * stats.php
 * (c)2018 http://dro1d.ru
 */

namespace Stat\Models;

use Zira;
use Dash;
use Stat;
use Zira\Permission;

class Stats extends Dash\Models\Model {
    
}