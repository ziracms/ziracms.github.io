<?php
/**
 * Zira project
 * zira.php
 * (c)2015 http://dro1d.ru
 */

class Zira extends \Zira\Zira {

}