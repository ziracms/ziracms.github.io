<?php
/**
 * Zira project
 * orm.php
 * (c)2015 https://github.com/ziracms/zira
 */

namespace Zira;

abstract class Orm extends Db\Orm{

}