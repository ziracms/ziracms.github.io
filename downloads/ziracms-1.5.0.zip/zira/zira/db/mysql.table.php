<?php
/**
 * Zira project.
 * table.php
 * (c)2015 https://github.com/ziracms/zira
 */

namespace Zira\Db;

abstract class Table extends Mysql\Table implements Implement\Table {

}