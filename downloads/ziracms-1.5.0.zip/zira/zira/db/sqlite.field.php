<?php
/**
 * Zira project.
 * sqlite.field.php
 * (c)2016 https://github.com/ziracms/zira
 */

namespace Zira\Db;

class Field extends Sqlite\Field implements Implement\Field {

}