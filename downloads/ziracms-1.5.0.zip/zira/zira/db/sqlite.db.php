<?php
/**
 * Zira project.
 * sqlite.db.php
 * (c)2016 https://github.com/ziracms/zira
 */

namespace Zira\Db;

class Db extends Sqlite\Db implements Implement\Db {

}