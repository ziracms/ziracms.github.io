<?php
/**
 * Zira project.
 * orm.php
 * (c)2015 https://github.com/ziracms/zira
 */

namespace Zira\Db;

abstract class Orm extends Mysql\Orm implements Implement\Orm {

}