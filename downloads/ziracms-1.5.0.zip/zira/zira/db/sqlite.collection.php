<?php
/**
 * Zira project.
 * sqlite.collection.php
 * (c)2016 https://github.com/ziracms/zira
 */

namespace Zira\Db;

class Collection extends Sqlite\Collection implements Implement\Collection {

}