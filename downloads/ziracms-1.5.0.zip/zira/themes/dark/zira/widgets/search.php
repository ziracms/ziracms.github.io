<div class="block widget-search-wrapper">
<?php if (isset($search)) echo $search; ?>
</div>