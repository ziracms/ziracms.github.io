<a id="dashpanel-fixed-button" href="<?php echo Zira\Helper::url('dash') ?>"><img src="<?php echo Zira\Helper::assetUrl('images/zira.png'); ?>" width="16" height="16" alt="Zira" />Zira</a>
