<script type="text/javascript">
    window.opener.oauth_vk_on_response('<?php echo $code; ?>');
    window.close();
</script>