<?php if (!empty($page_url)): ?>
<div class="fb-page block noframe"
     data-href="<?php echo Zira\Helper::html($page_url) ?>"
     data-small-header="false"
     data-width="500"
     data-adapt-container-width="true"
     data-hide-cover="false"
     data-show-facepile="true">
</div>
<?php endif; ?>