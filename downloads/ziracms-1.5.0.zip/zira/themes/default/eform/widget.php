<div class="block">
<?php echo $form; ?>
</div>