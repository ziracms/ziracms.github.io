<div class="record_preview_block"><label><?php echo tm('Views', 'stat') ?>:</label> <span><?php echo (int)$views ?></span></div>
