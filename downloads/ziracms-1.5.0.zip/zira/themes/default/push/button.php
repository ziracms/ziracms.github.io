<div class="block">
<?php if (!empty($is_sidebar)): ?>
<div class="page-header">
<h2 class="widget-title"><?php echo tm('Subscription', 'push') ?></h2>
</div>
<?php endif; ?>
<button class="push-subscription-button btn btn-primary" disabled="disabled"><?php echo tm('Notifications are not supported', 'push') ?></button>
</div>