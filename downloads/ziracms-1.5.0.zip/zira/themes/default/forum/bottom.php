<div class="forum-bottom-link-wrapper">
<?php echo tm('Go to %s', 'forum', '<a href="'.Zira\Helper::url('forum').'">'.tm('forum', 'forum').' &rsaquo;&rsaquo;</a>'); ?>
</div>